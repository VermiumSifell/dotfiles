---@meta

---@class cc.EventListenerFocus :cc.EventListener
local EventListenerFocus={ }
cc.EventListenerFocus=EventListenerFocus




---* 
---@return boolean
function EventListenerFocus:init () end
---* / Overrides
---@return self
function EventListenerFocus:clone () end
---* 
---@return boolean
function EventListenerFocus:checkAvailable () end
---* 
---@return self
function EventListenerFocus:EventListenerFocus () end